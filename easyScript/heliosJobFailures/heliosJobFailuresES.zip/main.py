#!/usr/bin/env python

### import Cohesity python module
from pyhesity import *
from datetime import datetime
import smtplib
import email.message
import email.utils
import argparse

### command line arguments
parser = argparse.ArgumentParser()
parser.add_argument('-v', '--vip', type=str, default='helios.cohesity.com')
parser.add_argument('-u', '--username', type=str, default='helios')
parser.add_argument('-d', '--domain', type=str, default='local')
parser.add_argument('-pw', '--password', type=str, default=None)
parser.add_argument('-s', '--mailserver', type=str)
parser.add_argument('-p', '--mailport', type=int, default=25)
parser.add_argument('-t', '--sendto', action='append', type=str)
parser.add_argument('-f', '--sendfrom', type=str)

args = parser.parse_args()

vip = args.vip
username = args.username
domain = args.domain
password = args.password
mailserver = args.mailserver
mailport = args.mailport
sendto = args.sendto
sendfrom = args.sendfrom

consoleWidth = 100

### authenticate
apiauth(vip=vip, username=username, domain=domain, password=password)

finishedStates = ['kCanceled', 'kSuccess', 'kFailure']

now = datetime.now()
nowUsecs = dateToUsecs(now.strftime("%Y-%m-%d %H:%M:%S"))

title = 'Helios Job Failure Report'
message = '<html><body style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; background-color: #f1f3f6; color: #444444;">'
message += '<div style="background-color: #fff; width:fit-content; padding: 2px 6px 8px 6px; font-weight: 300; box-shadow: 1px 2px 4px #cccccc; border-radius: 4px;">'
message += '<p style="font-weight: bold;">Helios Job Failure Report (%s)</p>' % now.date()
failureCount = 0

for hcluster in heliosClusters():
    failureDetected = False
    heliosCluster(hcluster['name'])
    cluster = api('get', 'cluster')
    if cluster:
        printedClusterName = False
        # for each active job
        jobs = api('get', 'protectionJobs')
        if jobs:
            for job in jobs:
                if 'isDeleted' not in job and ('isActive' not in job or job['isActive'] is not False) and ('isPaused' not in job or job['isPaused'] is not True):
                    jobId = job['id']
                    jobName = job['name']
                    runs = api('get', 'protectionRuns?jobId=%s&numRuns=2' % jobId)
                    for run in runs:
                        # get backup run time
                        startTimeUsecs = run['backupRun']['stats']['startTimeUsecs']
                        status = run['backupRun']['status']
                        if status == 'kFailure':
                            # handle run failure
                            failureCount += 1
                            if failureDetected is False:
                                print("\n%s" % cluster['name'].upper())
                                message += '<hr style="border: 1px solid #eee;"/><span style="font-weight: bold;">%s</span><br/>' % cluster['name'].upper()
                                failureDetected = True
                            print("  %s (%s) %s" % (job['name'].upper(), job['environment'][1], (usecsToDate(run['backupRun']['stats']['startTimeUsecs']))))
                            message += '<span style="margin-left: 20px; font-weight: normal; color: #000;">%s:</span> <span style="font-weight: 300;">(%s) %s</span><br/>' % (job['name'].upper(), job['environment'][1], (usecsToDate(run['backupRun']['stats']['startTimeUsecs'])))

                            if 'sourceBackupStatus' in run['backupRun']:
                                for source in run['backupRun']['sourceBackupStatus']:
                                    if source['status'] == 'kFailure':
                                        objectReport = "      %s (%s)" % (source['source']['name'].upper(), source['error'])
                                        if len(objectReport) > consoleWidth:
                                            objectReport = '%s...' % objectReport[0: consoleWidth - 5]
                                        print(objectReport)
                                        objectError = source['error']
                                        if len(objectError) + len(source['source']['name']) > 80:
                                            objectError = '%s...' % objectError[0: (77 - len(source['source']['name']))]
                                        message += '<span style="margin-left: 60px; font-weight: normal; color: #000;">%s:</span> <span style="font-weight: 300;">%s</span><br/>' % (source['source']['name'].upper(), objectError)
                            break
    else:
        print('%-15s: (trouble accessing cluster)' % hcluster['name'])

if failureCount == 0:
    print('No failures recorded')
else:
    message += '</body></html>'
    # email report
    if mailserver is not None:
        print('\nSending report to %s...' % ', '.join(sendto))
        msg = email.message.Message()
        msg['Subject'] = title
        msg['From'] = sendfrom
        msg['To'] = ','.join(sendto)
        msg.add_header('Content-Type', 'text/html')
        msg.set_payload(message)
        smtpserver = smtplib.SMTP(mailserver, mailport)
        smtpserver.sendmail(sendfrom, sendto, msg.as_string())
        smtpserver.quit()
