#!/usr/bin/env python
"""Cohesity Python REST API Wrapper Module - v2.0.9 - Brian Seltzer - Mar 2020"""

from datetime import datetime
import time
import json
import requests
import urllib3
import requests.packages.urllib3

__all__ = ['apiauth',
           'api',
           'usecsToDate',
           'dateToUsecs',
           'timeAgo',
           'dayDiff',
           'apiconnected',
           'apidrop',
           'heliosCluster',
           'heliosClusters']

requests.packages.urllib3.disable_warnings()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

APIROOT = ''
HEADER = ''
AUTHENTICATED = False
APIMETHODS = ['get', 'post', 'put', 'delete']


### authentication
def apiauth(vip='helios.cohesity.com', username='helios', domain='local', password=None, quiet=None, helios=False):
    """authentication function"""
    global APIROOT
    global HEADER
    global AUTHENTICATED
    global HELIOSCLUSTERS
    global CONNECTEDHELIOSCLUSTERS

    if helios is True:
        vip = 'helios.cohesity.com'
    pwd = password
    HEADER = {'accept': 'application/json', 'content-type': 'application/json'}
    APIROOT = 'https://' + vip + '/irisservices/api/v1'
    if vip == 'helios.cohesity.com':
        HEADER = {'accept': 'application/json', 'content-type': 'application/json', 'apiKey': pwd}
        URL = 'https://helios.cohesity.com/mcm/clusters/connectionStatus'
        try:
            HELIOSCLUSTERS = (requests.get(URL, headers=HEADER, verify=False)).json()
            CONNECTEDHELIOSCLUSTERS = [cluster for cluster in HELIOSCLUSTERS if cluster['connectedToCluster'] is True]
            AUTHENTICATED = True
            if(quiet is None):
                print("Connected!")
        except requests.exceptions.RequestException as e:
            AUTHENTICATED = False
            if quiet is None:
                print(e)
    else:
        creds = json.dumps({"domain": domain, "password": pwd, "username": username})

        url = APIROOT + '/public/accessTokens'
        try:
            response = requests.post(url, data=creds, headers=HEADER, verify=False)
            if response != '':
                if response.status_code == 201:
                    accessToken = response.json()['accessToken']
                    tokenType = response.json()['tokenType']
                    HEADER = {'accept': 'application/json',
                              'content-type': 'application/json',
                              'authorization': tokenType + ' ' + accessToken}
                    AUTHENTICATED = True
                    if(quiet is None):
                        print("Connected!")
                else:
                    print(response.json()['message'])
        except requests.exceptions.RequestException as e:
            AUTHENTICATED = False
            if quiet is None:
                print(e)


def apiconnected():
    return AUTHENTICATED


def apidrop():
    global AUTHENTICATED
    AUTHENTICATED = False


def heliosCluster(clusterName=None, verbose=False):
    global HEADER
    if clusterName is not None:
        if isinstance(clusterName, basestring) is not True:
            clusterName = clusterName['name']
        accessCluster = [cluster for cluster in CONNECTEDHELIOSCLUSTERS if cluster['name'].lower() == clusterName.lower()]
        if not accessCluster:
            print('Cluster %s not connected to Helios' % clusterName)
        else:
            HEADER['accessClusterId'] = str(accessCluster[0]['clusterId'])
            if verbose is True:
                print('Using %s' % clusterName)
    else:
        print("\n{0:<20}{1:<36}{2}".format('ClusterID', 'SoftwareVersion', "ClusterName"))
        print("{0:<20}{1:<36}{2}".format('---------', '---------------', "-----------"))
        for cluster in sorted(CONNECTEDHELIOSCLUSTERS, key=lambda cluster: cluster['name'].lower()):
            print("{0:<20}{1:<36}{2}".format(cluster['clusterId'], cluster['softwareVersion'], cluster['name']))


def heliosClusters():
    return sorted(CONNECTEDHELIOSCLUSTERS, key=lambda cluster: cluster['name'].lower())


### api call function
def api(method, uri, data=None, quiet=None):
    """api call function"""
    if AUTHENTICATED is False:
        print('Not Connected')
        return None
    response = ''
    if uri[0] != '/':
        uri = '/public/' + uri
    if method in APIMETHODS:
        try:
            if method == 'get':
                response = requests.get(APIROOT + uri, headers=HEADER, verify=False)
            if method == 'post':
                response = requests.post(APIROOT + uri, headers=HEADER, json=data, verify=False)
            if method == 'put':
                response = requests.put(APIROOT + uri, headers=HEADER, json=data, verify=False)
            if method == 'delete':
                response = requests.delete(APIROOT + uri, headers=HEADER, json=data, verify=False)
        except requests.exceptions.RequestException as e:
            if quiet is None:
                print(e)

        if isinstance(response, bool):
            return ''
        if response != '':
            if response.status_code == 204:
                return ''
            if response.status_code == 404:
                if quiet is None:
                    print('Invalid api call: ' + uri)
                return None
            try:
                responsejson = response.json()
            except ValueError:
                return ''
            if isinstance(responsejson, bool):
                return ''
            if responsejson is not None:
                if 'errorCode' in responsejson:
                    if quiet is None:
                        if 'message' in responsejson:
                            print('\033[93m' + responsejson['errorCode'][1:] + ': ' + responsejson['message'] + '\033[0m')
                        else:
                            print(responsejson)
                    return None
                else:
                    return responsejson
    else:
        if quiet is None:
            print("invalid api method")


### convert usecs to date
def usecsToDate(uedate):
    """Convert Unix Epoc Microseconds to Date String"""
    uedate = int(uedate) / 1000000
    return datetime.fromtimestamp(uedate).strftime('%Y-%m-%d %H:%M:%S')


### convert date to usecs
def dateToUsecs(datestring):
    """Convert Date String to Unix Epoc Microseconds"""
    dt = datetime.strptime(datestring, "%Y-%m-%d %H:%M:%S")
    return int(time.mktime(dt.timetuple())) * 1000000


### convert date difference to usecs
def timeAgo(timedelta, timeunit):
    """Convert Date Difference to Unix Epoc Microseconds"""
    nowsecs = int(time.mktime(datetime.now().timetuple())) * 1000000
    secs = {'seconds': 1, 'sec': 1, 'secs': 1,
            'minutes': 60, 'min': 60, 'mins': 60,
            'hours': 3600, 'hour': 3600,
            'days': 86400, 'day': 86400,
            'weeks': 604800, 'week': 604800,
            'months': 2628000, 'month': 2628000,
            'years': 31536000, 'year': 31536000}
    age = int(timedelta) * int(secs[timeunit.lower()]) * 1000000
    return nowsecs - age


def dayDiff(newdate, olddate):
    """Return number of days between usec dates"""
    return int(round((newdate - olddate) / float(86400000000)))
