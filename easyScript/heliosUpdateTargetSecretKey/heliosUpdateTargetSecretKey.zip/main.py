#!/usr/bin/env python
"""Helios Update Secret Key for External Targets"""

from pyhesity import *
import smtplib
import email.message
import email.utils

### command line arguments
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('-k', '--apikey', type=str, required=True)
parser.add_argument('-a', '--accesskey', type=str, required=True)
parser.add_argument('-s', '--secretkey', type=str, required=True)
parser.add_argument('-n', '--targetname', type=str, default=None)
parser.add_argument('-c', '--clustername', type=str, default=None)
parser.add_argument('-m', '--mailserver', type=str, required=True)
parser.add_argument('-p', '--mailport', type=int, default=25)
parser.add_argument('-t', '--sendto', action='append', type=str, required=True)
parser.add_argument('-f', '--sendfrom', type=str, required=True)
args = parser.parse_args()

apikey = args.apikey
accesskey = args.accesskey
secretkey = args.secretkey
targetname = args.targetname
clustername = args.clustername
mailserver = args.mailserver
mailport = args.mailport
sendto = args.sendto
sendfrom = args.sendfrom

### authenticate
apiauth(vip='helios.cohesity.com', username='helios', domain='local', password=apikey)

message = 'Updated secret keys for external targets\n'

for hcluster in heliosClusters():
    if clustername is None or clustername.lower() == hcluster['name'].lower():
        heliosCluster(hcluster['name'])
        cluster = api('get', 'cluster')
        if cluster:
            print('%s' % hcluster['name'])
            message += '\nCluster: %s\n' % hcluster['name']
            vaults = api('get', 'vaults')
            if len(vaults) > 0:
                vaults = [v for v in vaults if 'amazon' in v['config'] and v['config']['amazon']['accessKeyId'] == accesskey]
                for vault in vaults:
                    if targetname is None or targetname.lower() == vault['name'].lower():
                        print('    updated key for target: %s' % vault['name'])
                        message += '\n    updated key for target: %s\n' % vault['name']
                        vault['config']['amazon']['secretAccessKey'] = secretkey
                        result = api('put', 'vaults/%s' % vault['id'], vault)
        else:
            print('%s (trouble accessing cluster)' % hcluster['name'])
            message += '\n%s (trouble accessing cluster)\n' % hcluster['name']

print('\nSending report to %s...' % ', '.join(sendto))
msg = email.message.Message()
msg['Subject'] = 'Cohesity Helios Archive Target Updates'
msg['From'] = sendfrom
msg['To'] = ','.join(sendto)
msg.add_header('Content-Type', 'text/plain')
msg.set_payload(message)
msg['Content-Transfer-Encoding'] = '8bit'
msg.set_payload(message, 'UTF-8')
smtpserver = smtplib.SMTP(mailserver, mailport)
smtpserver.sendmail(sendfrom, sendto, msg.as_string())
smtpserver.quit()
