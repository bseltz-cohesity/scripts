#!/usr/bin/env python
"""list old snapshots"""

# usage: ./oldSnapshotList.py -v mycluster -u admin -k 30

# import pyhesity wrapper module
from pyhesity import *
import smtplib
import email.message
import email.utils

# command line arguments
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('-v', '--vip', type=str, required=True)         # cluster to connect to
parser.add_argument('-u', '--username', type=str, required=True)    # username
parser.add_argument('-d', '--domain', type=str, default='local')    # (optional) domain - defaults to local
parser.add_argument('-pw', '--password', type=str, default=None)
parser.add_argument('-k', '--olderthan', type=int, required=True)  # number of days of snapshots to retain
parser.add_argument('-s', '--mailserver', type=str)
parser.add_argument('-p', '--mailport', type=int, default=25)
parser.add_argument('-t', '--sendto', action='append', type=str)
parser.add_argument('-f', '--sendfrom', type=str)

args = parser.parse_args()

vip = args.vip
username = args.username
domain = args.domain
olderthan = args.olderthan
password = args.password
mailserver = args.mailserver
mailport = args.mailport
sendto = args.sendto
sendfrom = args.sendfrom

# authenticate
apiauth(vip=vip, username=username, domain=domain, password=password)

# get cluster Id
# clusterId = api('get', 'cluster')['id']

title = 'Old Snapshots on %s' % vip
message = 'Found old snapshots on %s\n\n' % vip

print("\nSearching for old snapshots...\n")

foundOldSnapshots = False

for job in sorted(api('get', 'protectionJobs'), key=lambda job: job['name'].lower()):
    for run in api('get', 'protectionRuns?jobId=%s&numRuns=999999&excludeTasks=true&excludeNonRestoreableRuns=true' % job['id']):
        startdate = usecsToDate(run['copyRun'][0]['runStartTimeUsecs'])
        startdateusecs = run['copyRun'][0]['runStartTimeUsecs']
        if startdateusecs < timeAgo(olderthan, 'days') and run['backupRun']['snapshotsDeleted'] is False:
            print("%s: %s (%s)" % (startdate, job['name'], run['backupRun']['runType'][1:]))
            message += "%s: %s (%s)\n" % (startdate, job['name'], run['backupRun']['runType'][1:])
            foundOldSnapshots = True

if mailserver is not None and foundOldSnapshots is True:
    print('\nSending report to %s...\n' % ', '.join(sendto))
    msg = email.message.Message()
    msg['Subject'] = title
    msg['From'] = sendfrom
    msg['To'] = ','.join(sendto)
    msg.add_header('Content-Type', 'text/plain')
    msg.set_payload(message)
    smtpserver = smtplib.SMTP(mailserver, mailport)
    smtpserver.sendmail(sendfrom, sendto, msg.as_string())
    smtpserver.quit()
