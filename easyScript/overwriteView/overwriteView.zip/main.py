#!/usr/bin/env python

from pyhesity import *
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-v', '--vip', type=str, default='helios.cohesity.com')
parser.add_argument('-u', '--username', type=str, default='helios')
parser.add_argument('-d', '--domain', type=str, default='local')
parser.add_argument('-c', '--clustername', type=str, default=None)
parser.add_argument('-mcm', '--mcm', action='store_true')
parser.add_argument('-i', '--useApiKey', action='store_true')
parser.add_argument('-pwd', '--password', type=str, required=True)
parser.add_argument('-s', '--sourceview', type=str, required=True)
parser.add_argument('-t', '--targetview', type=str, required=True)

args = parser.parse_args()

vip = args.vip
username = args.username
domain = args.domain
clustername = args.clustername
mcm = args.mcm
useApiKey = args.useApiKey
password = args.password
sourceview = args.sourceview
targetview = args.targetview

# authenticate
apiauth(vip=vip, username=username, domain=domain, password=password, useApiKey=useApiKey, helios=mcm, prompt=False)

# if connected to helios or mcm, select access cluster
if mcm or vip.lower() == 'helios.cohesity.com':
    if clustername is not None:
        heliosCluster(clustername)
    else:
        print('-clustername is required when connecting to Helios or MCM')
        exit(1)

# exit if not authenticated
if apiconnected() is False:
    print('authentication failed')
    exit(1)

views = api('get', 'views')
if 'views' in views and views['views'] is not None and len(views['views']) > 0:
    sview = [v for v in views['views'] if v['name'].lower() == sourceview.lower()]
    if sview is not None and len(sview) > 0:
        sview = sview[0]
    else:
        print('Source view %s not found' % sourceview)
        exit(1)
    tview = [v for v in views['views'] if v['name'].lower() == targetview.lower()]
    if tview is not None and len(tview) > 0:
        tview = tview[0]
    else:
        print('Target view %s not found' % targetview)
        exit(1)
    response = api('post', 'views/overwrite', {
        'sourceViewName': sview['name'],
        'targetViewName': tview['name']
    })
    if response is not None and 'name' in response:
        print('%s overwritten successfully' % response['name'])
        exit(0)
else:
    print('No views found')
exit(1)
