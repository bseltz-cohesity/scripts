#!/usr/bin/env python

from pyhesity import *
from time import sleep
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-v', '--vip', type=str, default='helios.cohesity.com')
parser.add_argument('-u', '--username', type=str, default='helios')
parser.add_argument('-d', '--domain', type=str, default='local')
parser.add_argument('-c', '--clustername', type=str, default=None)
parser.add_argument('-mcm', '--mcm', action='store_true')
parser.add_argument('-i', '--useApiKey', action='store_true')
parser.add_argument('-pwd', '--password', type=str, required=True)
parser.add_argument('-s', '--sourceview', type=str, required=True)
parser.add_argument('-t', '--targetview', type=str, required=True)
parser.add_argument('-j', '--waitforjob', type=str, default=None)
parser.add_argument('-l', '--lookbackhours', type=int, default=23)
parser.add_argument('-z', '--sleeptime', type=int, default=60)

args = parser.parse_args()

vip = args.vip
username = args.username
domain = args.domain
clustername = args.clustername
mcm = args.mcm
useApiKey = args.useApiKey
password = args.password
sourceview = args.sourceview
targetview = args.targetview
jobname = args.waitforjob
lookbackhours = args.lookbackhours
sleeptime = args.sleeptime

# authenticate
apiauth(vip=vip, username=username, domain=domain, password=password, useApiKey=useApiKey, helios=mcm, prompt=False)

# if connected to helios or mcm, select access cluster
if mcm or vip.lower() == 'helios.cohesity.com':
    if clustername is not None:
        heliosCluster(clustername)
    else:
        print('-clustername is required when connecting to Helios or MCM')
        exit(1)

# exit if not authenticated
if apiconnected() is False:
    print('authentication failed')
    exit(1)

finishedStates = ['Succeeded', 'Canceled', 'Failed', 'Warning', 'SucceededWithWarning']
badStates = ['Canceled', 'Failed']

proceed = True
if jobname is not None:
    proceed = False
    job = None
    jobs = api('get', 'data-protect/protection-groups', v=2)
    if jobs is not None and 'protectionGroups' in jobs and jobs['protectionGroups'] is not None and len(jobs['protectionGroups']) > 0:
        job = [j for j in jobs['protectionGroups'] if j['name'].lower() == jobname.lower()]
        if job is not None and len(job) > 0:
            job = job[0]
    if job is None:
        print('%s not found' % jobname)
        exit(1)

    archiveFinished = False
    reportedWaiting = False
    while archiveFinished is False:
        runs = api('get', 'data-protect/protection-groups/%s/runs?startTimeUsecs=%s&numRuns=1' % (job['id'], timeAgo(lookbackhours, 'hours')), v=2)
        if runs is not None and 'runs' in runs and runs['runs'] is not None and len(runs['runs']) > 0:
            run = runs['runs'][0]
            if 'archivalInfo' in run and run['archivalInfo'] is not None:
                if 'archivalTargetResults' in run['archivalInfo'] and run['archivalInfo']['archivalTargetResults'] is not None:
                    if len(run['archivalInfo']['archivalTargetResults']) > 0:
                        for result in run['archivalInfo']['archivalTargetResults']:
                            if 'status' in result and result['status'] in finishedStates:
                                if result['status'] in badStates:
                                    print('Archive of %s status: %s' % (jobname, result['status']))
                                    exit(1)
                                else:
                                    print('Archive of %s status: %s' % (jobname, result['status']))
                                    proceed = True
                                    archiveFinished = True
        else:
            print('No runs found for %s in the last %s hours' % (jobname, lookbackhours))
            exit(1)
        if archiveFinished is False:
            if reportedWaiting is False:
                print('Waiting for archive of %s' % jobname)
                reportedWaiting = True
            sleep(sleeptime)


if proceed is True:
    views = api('get', 'views')
    if 'views' in views and views['views'] is not None and len(views['views']) > 0:
        sview = [v for v in views['views'] if v['name'].lower() == sourceview.lower()]
        if sview is not None and len(sview) > 0:
            sview = sview[0]
        else:
            print('Source view %s not found' % sourceview)
            exit(1)
        tview = [v for v in views['views'] if v['name'].lower() == targetview.lower()]
        if tview is not None and len(tview) > 0:
            tview = tview[0]
        else:
            print('Target view %s not found' % targetview)
            exit(1)
        response = api('post', 'views/overwrite', {
            'sourceViewName': sview['name'],
            'targetViewName': tview['name']
        })
        if response is not None and 'name' in response:
            print('View %s overwritten successfully' % response['name'])
            exit(0)
    else:
        print('No views found')
    exit(1)
