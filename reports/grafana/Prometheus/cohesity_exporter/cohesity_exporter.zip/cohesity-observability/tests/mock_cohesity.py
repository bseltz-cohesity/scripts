#!/usr/bin/env python3
"""
Minimal HTTPS mock of the Cohesity endpoints the exporter uses, shaped after the
v1/v2 OpenAPI specs. Used for local testing only.

  python3 mock_cohesity.py --port 8441 --mode cluster --dataset dc1
  python3 mock_cohesity.py --port 8442 --mode helios          # serves dc3 + dc4
"""
import argparse
import json
import ssl
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

TB = 1024 ** 4
NOW_MS = lambda: int(time.time() * 1000)


def pg(name, status, paused=False):
    run = {'localBackupInfo': {'status': status}} if status else None
    d = {'id': '1:2:%s' % name, 'name': name, 'isPaused': paused}
    if run:
        d['lastRun'] = run
    return d


DATASETS = {
    'dc1': {
        'id': 1001, 'name': 'dc1', 'ver': '7.1.2', 'total': 100 * TB, 'used': 61 * TB, 'avail': 39 * TB,
        'nodes': [(1, '10.0.0.1'), (2, '10.0.0.2'), (3, '10.0.0.3')], 'down': [], 'thr': 812345678,
        'pgs': [pg('a', 'Succeeded'), pg('b', 'Succeeded'), pg('c', 'Failed'), pg('d', 'SucceededWithWarning'),
                pg('e', 'Running'), pg('f', None), pg('g', 'Succeeded', paused=True)],
        'alerts': [{'category': 'kDisk', 'criticalCount': 2, 'warningCount': 1, 'infoCount': 0, 'totalCount': 3},
                   {'category': 'kBackupRestore', 'criticalCount': 0, 'warningCount': 4, 'infoCount': 2, 'totalCount': 6}],
    },
    'dc2': {  # one node down, alerts endpoint broken
        'id': 1002, 'name': 'dc2', 'ver': '7.0.1', 'total': 50 * TB, 'used': 47 * TB, 'avail': 3 * TB,
        'nodes': [(1, '10.1.0.1'), (2, '10.1.0.2'), (3, '10.1.0.3'), (4, '10.1.0.4')], 'down': [3], 'thr': 12345,
        'pgs': [pg('x', 'Failed'), pg('y', 'Failed')], 'alerts': None,
    },
    'dc3': {
        'id': 1003, 'name': 'dc3', 'ver': '7.1.2', 'total': 20 * TB, 'used': 5 * TB, 'avail': 15 * TB,
        'nodes': [(1, '10.3.0.1')], 'down': [], 'thr': 0, 'pgs': [pg('p', 'Succeeded')], 'alerts': [],
    },
    'dc4': {
        'id': 1004, 'name': 'dc4', 'ver': '7.1.2', 'total': 20 * TB, 'used': 10 * TB, 'avail': 10 * TB,
        'nodes': [(1, '10.4.0.1'), (2, '10.4.0.2')], 'down': [], 'thr': 5555, 'pgs': [], 'alerts': [],
    },
}


class H(BaseHTTPRequestHandler):
    mode = 'cluster'
    dataset = 'dc1'
    api_key = 'key-dc1'
    gen = None        # generated helios cluster list
    latency = 0.0

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.headers.get('apiKey') != self.api_key:
            return self._send({'errorCode': 'KStatusUnauthorized', 'message': 'API Key does not exist'}, 401)
        time.sleep(self.latency)
        u = urlparse(self.path)
        p = u.path
        if p == '/mcm/clusters/connectionStatus' and self.gen is not None:
            return self._send(self.gen)
        if p == '/mcm/clusters/connectionStatus':
            return self._send([{'name': n, 'clusterId': DATASETS[n]['id'], 'softwareVersion': DATASETS[n]['ver'],
                                'connectedToCluster': True} for n in ('dc3', 'dc4')]
                              + [{'name': 'dc5-offline', 'clusterId': 1005, 'softwareVersion': '7.1.2', 'connectedToCluster': False}])
        if self.mode == 'helios':
            cid = self.headers.get('accessClusterId')
            ds = next((d for d in DATASETS.values() if str(d['id']) == cid), None)
            if ds is None:
                return self._send({'errorCode': 'KInvalid', 'message': 'no accessClusterId'}, 400)
        else:
            ds = DATASETS[self.dataset]

        if p.endswith('/public/sessionUser/preferences'):
            return self._send({'preferences': {}})
        if p.endswith('/public/cluster'):
            return self._send({'id': ds['id'], 'name': ds['name'], 'clusterSoftwareVersion': ds['ver'],
                               'clusterType': 'kPhysical', 'nodeCount': len(ds['nodes'])})
        if p.endswith('/public/stats/storage'):
            return self._send({'totalCapacityBytes': ds['total'], 'localUsageBytes': ds['used'],
                               'localAvailableBytes': ds['avail']})
        if p.endswith('/public/nodes'):
            return self._send([{'id': i, 'ip': ip, 'hostName': 'node%d.%s' % (i, ds['name']),
                                'inMaintenanceMode': False, 'offlineDiskCount': 1 if i in ds['down'] else 0,
                                'isMarkedForRemoval': False, 'upgradeInProgress': False}
                               for i, ip in ds['nodes']])
        if p.endswith('/public/cluster/status'):
            return self._send({'clusterId': ds['id'], 'name': ds['name'], 'stoppedServices': ['kApollo'] if ds['down'] else [],
                               'nodeStatuses': [{'id': i, 'ip': ip, 'inCluster': True, 'inMaintenanceMode': False}
                                                for i, ip in ds['nodes'] if i not in ds['down']]})
        if p.endswith('/public/statistics/timeSeriesStats'):
            t = NOW_MS()
            return self._send({'metricName': 'kNumBytesWritten', 'dataPointVec': [
                {'timestampMsecs': t - 360000, 'data': {'int64Value': 1}},
                {'timestampMsecs': t - 180000, 'data': {'int64Value': ds['thr']}},
                {'timestampMsecs': t, 'data': {}}]})  # newest point empty -> must be skipped
        if p.endswith('/v2/data-protect/protection-groups'):
            return self._send({'protectionGroups': ds['pgs']})
        if p.endswith('/v2/alerts-summary'):
            if ds['alerts'] is None:
                return self._send({'errorCode': 'KInternal', 'message': 'alerts backend unavailable'}, 500)
            return self._send({'alertsSummary': ds['alerts']})
        return self._send({'errorCode': 'KNotFound', 'message': 'not mocked: ' + p}, 404)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, required=True)
    ap.add_argument('--mode', default='cluster', choices=['cluster', 'helios'])
    ap.add_argument('--dataset', default='dc1')
    ap.add_argument('--api-key', default=None)
    ap.add_argument('--gen-connected', type=int, default=0, help='helios: generate N connected clusters')
    ap.add_argument('--gen-offline', type=int, default=0, help='helios: generate N disconnected clusters')
    ap.add_argument('--latency', type=float, default=0.0, help='seconds of delay per request')
    ap.add_argument('--cert', default='/tmp/mock-cert.pem')
    ap.add_argument('--key', default='/tmp/mock-key.pem')
    a = ap.parse_args()
    H.mode, H.dataset, H.latency = a.mode, a.dataset, a.latency
    if a.gen_connected or a.gen_offline:
        lst = []
        for i in range(a.gen_connected):
            n = 'gen%02d' % i
            DATASETS[n] = dict(DATASETS['dc4'], id=2000 + i, name=n)
            lst.append({'name': n, 'clusterId': 2000 + i, 'softwareVersion': '7.1.2', 'connectedToCluster': True})
        for i in range(a.gen_offline):
            lst.append({'name': 'off%02d' % i, 'clusterId': 3000 + i, 'softwareVersion': '7.1.2', 'connectedToCluster': False})
        H.gen = lst
    H.api_key = a.api_key or ('key-helios' if a.mode == 'helios' else 'key-' + a.dataset)
    srv = HTTPServer(('127.0.0.1', a.port), H)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(a.cert, a.key)
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    srv.serve_forever()
